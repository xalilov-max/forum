from django.shortcuts import render, redirect, get_object_or_404
from .models import Topic, Comment
from .forms import TopicForm, CommentForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, logout
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
    else:
        form = UserCreationForm()
    return render(request, 'forum/register.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('index')

def index(request):
    topics = Topic.objects.all()
    return render(request, 'forum/index.html', {'topics': topics})

def topic_create(request):
    if request.method == 'POST':
        form = TopicForm(request.POST)
        if form.is_valid():
            topic = form.save(commit=False)
            topic.author = request.user
            topic.save()
            return redirect('index')
    else:
        form = TopicForm()
    return render(request, 'forum/topic_form.html', {'form': form})

def topic_detail(request, pk):
    topic = get_object_or_404(Topic, pk=pk)
    comments = topic.comments.all()
    if request.method == 'POST':
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.topic = topic
            comment.author = request.user
            comment.save()
            return redirect('topic_detail', pk=topic.pk)
    else:
        comment_form = CommentForm()
    return render(request, 'forum/topic_detail.html', {
        'topic': topic,
        'comments': comments,
        'comment_form': comment_form
    })

def topic_update(request, pk):
    topic = get_object_or_404(Topic, pk=pk)
    if request.method == 'POST':
        form = TopicForm(request.POST, instance=topic)
        if form.is_valid():
            form.save()
            return redirect('topic_detail', pk=topic.pk)
    else:
        form = TopicForm(instance=topic)
    return render(request, 'forum/topic_form.html', {'form': form})

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  
            return redirect('index') 
    else:
        form = UserCreationForm()
    return render(request, 'forum/register.html', {'form': form})

