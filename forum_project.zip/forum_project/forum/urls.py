from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('topic/new/', views.topic_create, name='topic_create'),
    path('topic/<int:pk>/', views.topic_detail, name='topic_detail'),
    path('topic/<int:pk>/edit/', views.topic_update, name='topic_update'),
    path('register/', views.register, name='register'),
    path('logout/', views.user_logout, name='logout'),
]

